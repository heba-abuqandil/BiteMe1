package gui;

public enum PickUpType {
	Delivery,TakeAway;
}
