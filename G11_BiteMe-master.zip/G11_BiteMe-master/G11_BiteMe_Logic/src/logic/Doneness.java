package logic;

public enum Doneness {
	Rare,MediumRare,Medium,MediumWell,WellDone;
}
