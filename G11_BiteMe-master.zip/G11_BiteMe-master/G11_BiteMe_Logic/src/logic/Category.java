package logic;

public enum Category {
	Salad,Sweets,Drinks,MainMeal;
}
