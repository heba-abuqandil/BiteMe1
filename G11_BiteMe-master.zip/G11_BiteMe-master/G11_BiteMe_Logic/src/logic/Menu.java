package logic;

public class Menu {
	private int MenuID;
	
	public int getMenuID() {
		return MenuID;
	}

	public void setMenuID(int menuID) {
		MenuID = menuID;
	}

	public Menu(int menuID) {
		super();
		MenuID = menuID;
	}
}
