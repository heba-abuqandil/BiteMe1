package logic;

public enum Size {
	Large,Medium,Small;
}
